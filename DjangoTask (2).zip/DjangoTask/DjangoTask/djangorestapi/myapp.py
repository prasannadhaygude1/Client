import requests, json

# URL = "http://127.0.0.1:8000/createclient"
# data = {
#     'client_name':'Infotech',
#     'created_at':'2024-09-24',
#     'created_by':'Rohit'
# }
# json_data = json.dumps(data)
# r = requests.post(url=URL, data=json_data)
# data = r.json()
# print(data)

# URL = "http://127.0.0.1:8000/createproject"
# data = {
#     'project_name':'Fuel Delivery System',
#     'client': '1',
#     'user': 'admin'
#     'created_at': '',
#     'created_by': 'Shree'
#
# }
# json_data = json.dumps(data)
# r = requests.post(url=URL, data=json_data)
# data = r.json()
# print(data)

# URL = "http://127.0.0.1:8000/project_details"
# r = requests.get(url=URL)
# data = r.json()
# print(data)

URL = "http://127.0.0.1:8000/deleteclient/1"
r = requests.get(url=URL)
data = r.json()
print(data)